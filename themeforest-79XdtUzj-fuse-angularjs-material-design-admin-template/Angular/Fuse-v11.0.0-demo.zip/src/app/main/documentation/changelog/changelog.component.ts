import { Component } from '@angular/core';

@Component({
    selector   : 'docs-changelog',
    templateUrl: './changelog.component.html',
    styleUrls  : ['./changelog.component.scss']
})
export class DocsChangelogComponent
{
    constructor()
    {
    }
}
