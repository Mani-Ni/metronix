import { Component } from '@angular/core';

@Component({
    selector   : 'docs-components-material-color-picker',
    templateUrl: './material-color-picker.component.html',
    styleUrls  : ['./material-color-picker.component.scss']
})
export class DocsComponentsMaterialColorPickerComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
