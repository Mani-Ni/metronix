import { Component } from '@angular/core';

@Component({
    selector   : 'docs-components-shortcuts',
    templateUrl: './shortcuts.component.html',
    styleUrls  : ['./shortcuts.component.scss']
})
export class DocsComponentsShortcutsComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
