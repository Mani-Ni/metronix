import { Component } from '@angular/core';

@Component({
    selector   : 'docs-components-countdown',
    templateUrl: './countdown.component.html',
    styleUrls  : ['./countdown.component.scss']
})
export class DocsComponentsCountdownComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
